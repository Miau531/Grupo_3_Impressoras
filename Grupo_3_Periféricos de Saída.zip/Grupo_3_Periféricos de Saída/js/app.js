/* ==========================================================================
   WIKIHARDWARE - IMPRESSORAS STANDARD (UFCD 770 - GRUPO 3)
   LÓGICA JAVASCRIPT: ABAS, TROUBLESHOOTING, CALCULADORA E TEMA
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
    // Inicializar Componentes
    initThemeManager();
    initTabManager();
    initSubTechToggles();
    initCostCalculator();
    initTroubleshooting();
    initDiagnosticWizard();
});

/* ==========================================================================
   1. GESTÃO DO TEMA (CLARO / ESCURO)
   ========================================================================== */
function initThemeManager() {
    const themeToggleBtn = document.getElementById('theme-toggle');
    if (!themeToggleBtn) return;

    // Verificar se o utilizador já tem uma preferência gravada
    const savedTheme = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);

    themeToggleBtn.addEventListener('click', () => {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
    });
}

/* ==========================================================================
   2. GESTÃO DE ABAS (TABS NAVIGATION)
   ========================================================================== */
function initTabManager() {
    const tabButtons = document.querySelectorAll('.tab-button');
    const tabContents = document.querySelectorAll('.tab-content');

    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const targetTabId = button.getAttribute('data-tab');

            // Remover classes ativas de todos os botões e secções
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));

            // Adicionar classes ativas ao botão e secção clicados
            button.classList.add('active');
            const targetContent = document.getElementById(targetTabId);
            if (targetContent) {
                targetContent.classList.add('active');
            }

            // Scroll suave até ao topo do painel de conteúdo em mobile
            if (window.innerWidth <= 768) {
                window.scrollTo({
                    top: document.querySelector('.tabs-navigation').offsetTop - 20,
                    behavior: 'smooth'
                });
            }
        });
    });

    // Permitir ligação direta a uma aba via URL Hash (ex: #instalacao)
    const hash = window.location.hash;
    if (hash) {
        const correspondingBtn = document.querySelector(`.tab-button[data-tab="${hash.replace('#', '')}"]`);
        if (correspondingBtn) {
            correspondingBtn.click();
        }
    }
}

/* ==========================================================================
   3. SECÇÃO DE FUNCIONAMENTO - ALTERNAR SUB-TECNOLOGIAS
   ========================================================================== */
function initSubTechToggles() {
    const toggleContainers = document.querySelectorAll('.sub-tech-toggle');

    toggleContainers.forEach(container => {
        const buttons = container.querySelectorAll('.sub-tech-btn');
        const contents = container.querySelectorAll('.sub-tech-content');

        buttons.forEach(button => {
            button.addEventListener('click', () => {
                const targetId = button.getAttribute('data-sub-target');

                // Inativar botões e conteúdos do mesmo grupo
                buttons.forEach(btn => btn.classList.remove('active'));
                contents.forEach(content => content.classList.remove('active'));

                // Ativar o selecionado
                button.classList.add('active');
                const targetContent = container.querySelector(`#${targetId}`);
                if (targetContent) {
                    targetContent.classList.add('active');
                }
            });
        });
    });
}

/* ==========================================================================
   4. CALCULADORA INTERATIVA DE CUSTO E RENDIMENTO
   ========================================================================== */
function initCostCalculator() {
    const rangeVolume = document.getElementById('calc-volume');
    const rangePeriodo = document.getElementById('calc-periodo');
    
    const valVolume = document.getElementById('volume-val');
    const valPeriodo = document.getElementById('periodo-val');
    
    const barInkjet = document.getElementById('bar-inkjet');
    const barLaser = document.getElementById('bar-laser');
    
    const costInkjetText = document.getElementById('cost-inkjet-text');
    const costLaserText = document.getElementById('cost-laser-text');
    const totalPagesText = document.getElementById('total-pages-text');
    const verdictTitle = document.getElementById('verdict-title');
    const verdictDesc = document.getElementById('verdict-desc');
    const verdictIcon = document.getElementById('verdict-icon');

    if (!rangeVolume || !rangePeriodo) return;

    // Configuração dos Custos Base do Mercado (Valores Médios Estimados)
    const inkjet = {
        printerInitial: 50.00,       // Impressora barata
        consumableCost: 20.00,       // Tinteiro original médio
        consumableYield: 300,        // Páginas por tinteiro
        getCostPerPage: function() { return this.consumableCost / this.consumableYield; }
    };

    const laser = {
        printerInitial: 180.00,      // Impressora mais cara
        consumableCost: 65.00,       // Toner original médio
        consumableYield: 3000,       // Páginas por toner
        getCostPerPage: function() { return this.consumableCost / this.consumableYield; }
    };

    function recalculate() {
        const volumeMensal = parseInt(rangeVolume.value);
        const meses = parseInt(rangePeriodo.value);
        
        // Atualizar etiquetas visuais dos sliders
        valVolume.textContent = volumeMensal;
        valPeriodo.textContent = meses;

        const paginasTotais = volumeMensal * meses;
        totalPagesText.textContent = paginasTotais.toLocaleString('pt-PT');

        // Cálculo Jato de Tinta:
        // Custo total = Custo Impressora + (Tinteiros necessários * Preço Tinteiro)
        const tinteirosNecessarios = Math.ceil(paginasTotais / inkjet.consumableYield);
        const custoTotalInkjet = inkjet.printerInitial + (tinteirosNecessarios * inkjet.consumableCost);

        // Cálculo Laser:
        // Custo total = Custo Impressora + (Toners necessários * Preço Toner)
        const tonersNecessarios = Math.ceil(paginasTotais / laser.consumableYield);
        const custoTotalLaser = laser.printerInitial + (tonersNecessarios * laser.consumableCost);

        // Atualizar textos dos custos
        costInkjetText.textContent = custoTotalInkjet.toFixed(2) + '€';
        costLaserText.textContent = custoTotalLaser.toFixed(2) + '€';

        // Atualizar as barras visuais proporcionalmente
        const maxCost = Math.max(custoTotalInkjet, custoTotalLaser);
        const widthInkjet = (custoTotalInkjet / maxCost) * 100;
        const widthLaser = (custoTotalLaser / maxCost) * 100;

        barInkjet.style.width = widthInkjet + '%';
        barLaser.style.width = widthLaser + '%';

        // Definir o Veredicto
        if (custoTotalLaser < custoTotalInkjet) {
            verdictIcon.textContent = '⚡';
            verdictTitle.textContent = 'A tecnologia Laser é mais rentável!';
            const poupanca = custoTotalInkjet - custoTotalLaser;
            verdictDesc.textContent = `Ao fim de ${meses} meses, pouparia cerca de ${poupanca.toFixed(2)}€ optando por uma impressora laser. O investimento inicial mais alto compensa o menor custo do toner por página.`;
        } else {
            verdictIcon.textContent = '💧';
            verdictTitle.textContent = 'A tecnologia Jato de Tinta é ideal para si!';
            const diferenca = custoTotalLaser - custoTotalInkjet;
            verdictDesc.textContent = `Com o seu volume de impressão reduzido, o custo mais elevado de uma impressora laser não compensa. A jato de tinta permite economizar ${diferenca.toFixed(2)}€ a curto/médio prazo.`;
        }
    }

    // Ouvintes de eventos nos inputs dos sliders
    rangeVolume.addEventListener('input', recalculate);
    rangePeriodo.addEventListener('input', recalculate);

    // Primeira execução para inicializar
    recalculate();
}

/* ==========================================================================
   5. MENU DE TROUBLESHOOTING INTERATIVO
   ========================================================================== */
function initTroubleshooting() {
    const troubleOptions = document.querySelectorAll('.trouble-option-card');
    const viewHeader = document.getElementById('trouble-view-title');
    const viewSub = document.getElementById('trouble-view-sub');
    const stepsContainer = document.getElementById('trouble-steps-container');

    if (!stepsContainer) return;

    // Base de dados local com as resoluções
    const troubleDatabase = {
        offline: {
            title: "O computador diz que a impressora está offline",
            sub: "Muito comum em ligações USB e ligações de rede sem fios.",
            steps: [
                "<strong>Verifique as ligações físicas:</strong> Confirme se o cabo USB está bem encaixado na impressora e no PC, ou se o sinal Wi-Fi está estável.",
                "<strong>Remova as restrições no Windows:</strong> Aceda a <em>Definições > Dispositivos > Impressoras</em>. Dê duplo clique na sua impressora, abra o menu 'Impressora' na janela e certifique-se de que as opções <strong>'Pausar Impressão'</strong> e <strong>'Usar Impressora Offline'</strong> estão desmarcadas.",
                "<strong>Reinicie o Spooler de Impressão:</strong> Pressione <code>Windows + R</code>, escreva <code>services.msc</code>, localize o serviço <strong>Print Spooler</strong> (Spooler de Impressão), clique com o botão direito e selecione <strong>Reiniciar</strong>."
            ]
        },
        riscos: {
            title: "A impressão sai com riscos verticais",
            sub: "Este problema tem resoluções completamente distintas consoante a tecnologia.",
            steps: [
                "<strong>Se for Jato de Tinta (Tinteiros):</strong> Os bicos injetores de tinta podem estar obstruídos por tinta seca. Aceda ao software de manutenção da impressora e execute o ciclo de <strong>Limpeza de Cabeças de Impressão</strong> (pode requerer 2 ou 3 passagens).",
                "<strong>Se for Laser (Toner):</strong> Os riscos devem-se geralmente a sujidade ou desgaste no <strong>cilindro fotocondutor (Drum)</strong> ou no rolo fusor. Retire o toner e limpe o cilindro com muito cuidado recorrendo a um pano macio e seco, ou substitua a unidade do cilindro/toner se estiver danificada ou vazia.",
                "<strong>Calibração:</strong> Utilize a ferramenta de alinhamento de cabeças ou calibração no menu de ferramentas do driver da impressora."
            ]
        },
        papel: {
            title: "O papel encravou (Paper Jam)",
            sub: "Danos físicos podem ocorrer se puxar o papel à força na direção errada.",
            steps: [
                "<strong>Desligue o equipamento:</strong> Desligue a impressora imediatamente no botão Power e da tomada de parede para evitar ferimentos ou danos nos motores e engrenagens.",
                "<strong>Remova com cuidado:</strong> Abra as portas de acesso (frontal, traseira ou gaveta de papel). Puxe o papel encravado de forma suave e constante, <strong>sempre no sentido natural de saída do papel</strong>, usando as duas mãos para evitar que o papel se rasgue.",
                "<strong>Inspecione restos:</strong> Certifique-se de que não ficam pequenos fragmentos de papel rasgado presos nos rolos de alimentação ou sensores, o que causaria um erro persistente ao ligar novamente."
            ]
        }
    };

    function renderSolution(problemKey) {
        const data = troubleDatabase[problemKey];
        if (!data) return;

        viewHeader.textContent = data.title;
        viewSub.textContent = data.sub;
        
        // Limpar passos anteriores
        stepsContainer.innerHTML = '';

        // Inserir novos passos com animação de atraso gradual
        data.steps.forEach((stepText, index) => {
            const stepDiv = document.createElement('div');
            stepDiv.className = 'solution-step-item';
            stepDiv.style.opacity = '0';
            stepDiv.style.transform = 'translateY(5px)';
            stepDiv.style.transition = `all 0.3s ease ${index * 0.1}s`;
            
            stepDiv.innerHTML = `
                <div class="step-num-badge">${index + 1}</div>
                <div class="step-desc-text">${stepText}</div>
            `;
            
            stepsContainer.appendChild(stepDiv);
            
            // Trigger da animação
            setTimeout(() => {
                stepDiv.style.opacity = '1';
                stepDiv.style.transform = 'translateY(0)';
            }, 50);
        });
    }

    troubleOptions.forEach(option => {
        option.addEventListener('click', () => {
            // Remover active de todas as opções
            troubleOptions.forEach(o => o.classList.remove('active'));
            // Adicionar ao atual
            option.classList.add('active');
            
            const problem = option.getAttribute('data-problem');
            renderSolution(problem);
        });
    });

    // Mostrar a primeira por defeito
    renderSolution('offline');
}

/* ==========================================================================
   6. ASSISTENTE DE DIAGNÓSTICO INTERATIVO (ÁRVORE DE DECISÃO)
   ========================================================================== */
function initDiagnosticWizard() {
    const questionText = document.getElementById('wizard-question');
    const btnYes = document.getElementById('wizard-btn-yes');
    const btnNo = document.getElementById('wizard-btn-no');
    const btnRestart = document.getElementById('wizard-restart');
    const progressFill = document.getElementById('wizard-progress');
    const btnRow = document.getElementById('wizard-btn-row');

    if (!questionText || !btnYes || !btnNo || !btnRestart) return;

    // Estrutura em árvore de decisão
    const wizardTree = {
        start: {
            question: "A impressora apresenta algum sinal de funcionamento físico (luzes acesas, ecrã ligado, barulho de motores ao iniciar)?",
            yes: "luzes_erro",
            no: "cabo_alimentacao",
            progress: 20
        },
        // Ramo do "Não dá sinal"
        cabo_alimentacao: {
            question: "O cabo de alimentação está firmemente encaixado na tomada elétrica e na entrada traseira da impressora?",
            yes: "testar_tomada",
            no: "conectar_cabo",
            progress: 40
        },
        testar_tomada: {
            question: "Já testou ligar outro aparelho funcional nessa mesma tomada de parede?",
            yes: "fonte_queimada",
            no: "tentar_outra_tomada",
            progress: 60
        },
        tentar_outra_tomada: {
            question: "Por favor, ligue a impressora a uma tomada de parede diferente e tente ligá-la. O problema ficou resolvido?",
            yes: "resolvido_tomada",
            no: "fonte_queimada",
            progress: 80
        },
        conectar_cabo: {
            question: "Ligue o cabo firmemente nas duas extremidades e pressione o botão Power. A impressora deu sinal de vida?",
            yes: "resolvido_cabo",
            no: "testar_tomada",
            progress: 70
        },
        // Ramo do "Dá sinal de vida"
        luzes_erro: {
            question: "Existem mensagens de erro no ecrã da impressora ou luzes vermelhas/laranja a piscar continuamente?",
            yes: "tipo_erro",
            no: "conexao_pc",
            progress: 40
        },
        tipo_erro: {
            question: "A impressora acusa falta de papel, falta de consumível (tinta/toner) ou encravamento interno?",
            yes: "resolver_fisico",
            no: "erro_desconhecido",
            progress: 65
        },
        resolver_fisico: {
            question: "Abra a impressora, retire o papel encravado ou substitua os tinteiros/toner gastos. A luz vermelha de erro apagou?",
            yes: "resolvido_fisico",
            no: "erro_desconhecido",
            progress: 85
        },
        erro_desconhecido: {
            question: "Pode ser um erro eletrónico. Tente desligar a impressora da tomada durante 60 segundos e volte a ligar. Desapareceu o erro?",
            yes: "resolvido_reboot",
            no: "assistencia_tecnica",
            progress: 90
        },
        conexao_pc: {
            question: "O computador deteta a impressora ativa nas Definições do Windows (aparece a verde/pronta, sem a indicação 'offline')?",
            yes: "fila_impressao",
            no: "tipo_ligacao",
            progress: 60
        },
        tipo_ligacao: {
            question: "A impressora está ligada ao PC via cabo USB (e não por rede Wi-Fi)?",
            yes: "reconectar_usb",
            no: "verificar_wifi",
            progress: 75
        },
        reconectar_usb: {
            question: "Desligue e volte a ligar o cabo USB numa porta diferente do computador. O PC já reconhece a impressora?",
            yes: "resolvido_usb",
            no: "reinstalar_driver",
            progress: 90
        },
        verificar_wifi: {
            question: "Aceda ao menu da impressora e imprima uma página de configuração de rede. A impressora obteve um endereço IP local (ex: 192.168.1.X)?",
            yes: "reinstalar_driver",
            no: "configurar_rede",
            progress: 85
        },
        fila_impressao: {
            question: "Ao tentar imprimir, o trabalho de impressão fica retido na fila de espera com o estado 'Erro' ou 'A Enviar'?",
            yes: "reiniciar_spooler",
            no: "selecionar_predefinida",
            progress: 80
        },
        
        // Nós de Resolução Final (Terminais)
        resolvido_tomada: {
            isFinal: true,
            message: "🎉 <strong>Resolvido!</strong> O problema estava na tomada de parede anterior. Evite usar extensões sobrecarregadas.",
            progress: 100
        },
        resolvido_cabo: {
            isFinal: true,
            message: "🎉 <strong>Resolvido!</strong> O cabo de alimentação não estava bem inserido. Agora a impressora funciona normalmente.",
            progress: 100
        },
        resolvido_fisico: {
            isFinal: true,
            message: "🎉 <strong>Resolvido!</strong> A limpeza do encravamento ou a reposição de consumíveis limpou o estado de bloqueio.",
            progress: 100
        },
        resolvido_reboot: {
            isFinal: true,
            message: "🎉 <strong>Resolvido!</strong> O reinício elétrico limpou a memória temporária do controlador da impressora.",
            progress: 100
        },
        resolvido_usb: {
            isFinal: true,
            message: "🎉 <strong>Resolvido!</strong> Mudar de porta USB forçou o Windows a restabelecer a comunicação com o dispositivo.",
            progress: 100
        },
        fonte_queimada: {
            isFinal: true,
            message: "❌ <strong>Diagnóstico:</strong> A fonte de alimentação interna da impressora ou o cabo de corrente podem estar queimados. Sugerimos testar com outro cabo de alimentação compatível ou enviar o equipamento para assistência especializada.",
            progress: 100
        },
        assistencia_tecnica: {
            isFinal: true,
            message: "❌ <strong>Diagnóstico:</strong> Erro persistente de hardware. O sensor interno ou a placa mãe da impressora podem necessitar de reparação técnica oficial.",
            progress: 100
        },
        reinstalar_driver: {
            isFinal: true,
            message: "⚙️ <strong>Diagnóstico:</strong> Provável falha de comunicação ou Driver corrompido. Sugerimos aceder ao painel de controlo do Windows, remover a impressora, descarregar o driver mais recente no site do fabricante (HP, Epson, Canon, Brother, etc.) e efetuar a reinstalação limpa.",
            progress: 100
        },
        configurar_rede: {
            isFinal: true,
            message: "🔌 <strong>Diagnóstico:</strong> A impressora não está associada à sua rede local. Ligue a impressora no visor ao Wi-Fi correto (introduzindo a palavra-passe) ou ligue um cabo de rede (Ethernet) ao seu router para obter um endereço IP.",
            progress: 100
        },
        reiniciar_spooler: {
            isFinal: true,
            message: "⚙️ <strong>Diagnóstico:</strong> O serviço de impressão do Windows está bloqueado. Siga o guia do <strong>Spooler de Impressão</strong>: pressione <code>Win+R</code>, execute <code>services.msc</code>, procure por <strong>Spooler de Impressão (Print Spooler)</strong> e selecione a opção <strong>'Reiniciar'</strong>. Depois, remova a pausa na impressora.",
            progress: 100
        },
        selecionar_predefinida: {
            isFinal: true,
            message: "✔️ <strong>Diagnóstico:</strong> Verifique se a impressora correta foi selecionada no programa a partir do qual está a imprimir. Por vezes, o Windows envia por engano os documentos para uma impressora virtual (ex: Microsoft Print to PDF).",
            progress: 100
        }
    };

    let currentNodeKey = 'start';

    function renderStep() {
        const node = wizardTree[currentNodeKey];
        if (!node) return;

        // Atualizar barra de progresso
        progressFill.style.width = node.progress + '%';

        if (node.isFinal) {
            // Se for um nó de conclusão (resolução/diagnóstico)
            questionText.innerHTML = node.message;
            // Ocultar botões Sim/Não
            btnRow.style.display = 'none';
        } else {
            // Se for uma pergunta intermédia
            questionText.textContent = node.question;
            btnRow.style.display = 'flex';
        }
    }

    btnYes.addEventListener('click', () => {
        const node = wizardTree[currentNodeKey];
        if (node && node.yes) {
            currentNodeKey = node.yes;
            renderStep();
        }
    });

    btnNo.addEventListener('click', () => {
        const node = wizardTree[currentNodeKey];
        if (node && node.no) {
            currentNodeKey = node.no;
            renderStep();
        }
    });

    btnRestart.addEventListener('click', () => {
        currentNodeKey = 'start';
        renderStep();
    });

    // Iniciar o assistente na primeira carga
    renderStep();
}
